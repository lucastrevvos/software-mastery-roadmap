# Phase 00 · Lab 01 — Diagnóstico sem tutorial

## Cenário

Um colega diz apenas:

> “O programa não roda.”

Ele tentou executar:

```bash
python tools/report.py
```

Seu trabalho não é adivinhar a correção. É **investigar o ambiente**.

## Missão

Sem mover arquivos e sem alterar `verify.py`:

1. Descubra em qual diretório você está.
2. Inspecione a estrutura do projeto.
3. Localize `report.py`.
4. Execute o programa e observe a falha.
5. Descubra por que ele falha.
6. Execute o programa de uma forma válida.
7. Preencha `notes/diagnosis.md` explicando:
   - qual era o problema;
   - qual evidência levou você à conclusão;
   - qual comando válido você usou.
8. Rode:

```bash
python verify.py
```

## Regras

- Não modifique `verify.py`.
- Não altere `data/users.json`.
- Não mova `report.py`.
- Você pode ler qualquer arquivo do projeto.
- Pesquisar comandos é permitido; copiar uma solução completa não é o objetivo.

## Gate

O laboratório é concluído quando `python verify.py` terminar com:

```text
MASTERED: Phase 00 Lab 01
```

Boa investigação.
