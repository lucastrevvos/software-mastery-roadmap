# Diagnóstico

## 1. Diretório de trabalho usado quando o problema ocorreu

Escreva aqui.

## 2. O que falhou

Escreva aqui.

## 3. Evidência observada

Escreva aqui.

## 4. Causa

Escreva aqui.

## 5. Comando usado para executar corretamente

Escreva aqui.
