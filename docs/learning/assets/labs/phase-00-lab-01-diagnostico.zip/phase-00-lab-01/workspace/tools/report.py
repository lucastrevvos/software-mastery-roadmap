from pathlib import Path
import json

# Intencionalmente dependente do diretório de trabalho atual.
# O laboratório é descobrir o contexto correto de execução.
data_path = Path("data/users.json")

with data_path.open(encoding="utf-8") as f:
    users = json.load(f)

active = [user for user in users if user["active"]]

output_dir = Path("output")
output_dir.mkdir(exist_ok=True)
output_file = output_dir / "report.txt"

lines = [
    "ACTIVE USERS REPORT",
    "===================",
    *[f'{user["id"]}: {user["name"]}' for user in active],
]

output_file.write_text("\n".join(lines) + "\n", encoding="utf-8")

print(f"Report generated: {output_file}")
print(f"Active users: {len(active)}")
