from pathlib import Path
import sys

root = Path(__file__).resolve().parent
report = root / "output" / "report.txt"
diagnosis = root / "notes" / "diagnosis.md"

checks = []

checks.append(("Relatório foi gerado", report.exists()))

expected_lines = {
    "ACTIVE USERS REPORT",
    "101: Ada",
    "103: Linus",
}
if report.exists():
    content = report.read_text(encoding="utf-8")
    checks.append(("Relatório contém os usuários ativos esperados",
                   all(line in content for line in expected_lines)))
else:
    checks.append(("Relatório contém os usuários ativos esperados", False))

if diagnosis.exists():
    text = diagnosis.read_text(encoding="utf-8")
    placeholders = text.count("Escreva aqui.")
    checks.append(("Diagnóstico foi preenchido", placeholders == 0))
    lowered = text.lower()
    checks.append(("Diagnóstico menciona diretório/caminho/contexto",
                   any(term in lowered for term in ["diretório", "diretorio", "caminho", "path", "working directory", "cwd"])))
    checks.append(("Diagnóstico registra um comando Python",
                   "python" in lowered and "report.py" in lowered))
else:
    checks.extend([
        ("Diagnóstico foi preenchido", False),
        ("Diagnóstico menciona diretório/caminho/contexto", False),
        ("Diagnóstico registra um comando Python", False),
    ])

print("\nPhase 00 · Lab 01 — verifier\n")
passed = True
for label, ok in checks:
    mark = "PASS" if ok else "FAIL"
    print(f"[{mark}] {label}")
    passed = passed and ok

print()
if passed:
    print("MASTERED: Phase 00 Lab 01")
    sys.exit(0)
else:
    print("Ainda não. Use as falhas acima como evidência para continuar investigando.")
    sys.exit(1)
